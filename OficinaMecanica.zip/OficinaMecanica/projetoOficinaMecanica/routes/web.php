<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/cadastro','CadastroController@index');
Route::get('/pesquisa','PesquisaController@index');
Route::post('tratar', 'CadastroController@tratar');
Route::post('selecao','PesquisaController@selecao');
Route::post('pesquisaCliente','PesquisaController@pesquisaCliente');
Route::post('pesquisaVendedor','PesquisaController@pesquisaVendedor');
Route::post('pesquisaData','PesquisaController@pesquisaData');
