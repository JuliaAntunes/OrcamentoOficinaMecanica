<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cadastro extends Model
{
	protected $table = 'cadastro';
	protected $fillable = ['cliente','data','hora','vendedor','descricao','valor_orcamento'];
}
