<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Cadastro;

class PesquisaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('pesquisa');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function selecao(Request $dados)
    {
        $opcao = $dados->tipo_pesquisa;

        if($opcao == 1){
            return view('pesquisaCliente');
        }else 
            if($opcao == 2){
                return view('pesquisaVendedor');
            }else
                if($opcao == 3){
                    return view('pesquisaData');
                }
    }

    public function pesquisaCliente(Request $dados){
        $cliente = $dados->nomeCliente;
        
        $results = DB::table('cadastro')
                ->select('cliente','data','hora','vendedor','descricao','valor_orcamento')
                ->where('cliente','=', $cliente)
                ->get();

        return view('tabela',compact('results'));
    }

    public function pesquisaVendedor(Request $dados){
        $vendedor = $dados->nomeVendedor;
        
        $results = DB::table('cadastro')
                ->select('cliente','data','hora','vendedor','descricao','valor_orcamento')
                ->where('vendedor','=', $vendedor)
                ->get();

        return view('tabela',compact('results'));
    }

    public function pesquisaData(Request $dados){
        
        $dataInicio = $dados->dataInicio;
        $dataFim = $dados->dataFim;
        
        $results = DB::table('cadastro')
                ->select('cliente','data','hora','vendedor','descricao','valor_orcamento')
                ->where('data','>=',$dataInicio,'AND','data','<=',$dataFim)
                ->get();

        return view('tabela',compact('results'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
